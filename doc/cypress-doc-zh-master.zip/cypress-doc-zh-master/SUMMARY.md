# Summary

## 概述

* [为什么是Cypress？](./guides/why-cypress.md)
* [主要差异](./guides/key-diff.md)

## 入门

* [安装 Cypress](./guides/install-cypress.md)
* [核心](he-xin.md)

