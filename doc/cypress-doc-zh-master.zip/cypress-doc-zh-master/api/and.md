## and

创建一个断言。断言会自动充实，知道通过或者超时。

> 别名：`.should()`

> 注意：`.and()` 假设你已经熟悉断言等核心概念了。

## Syntax

```
.and(chainers)
.and(chainers, value)
.and(chainers, method, value)
.and(callbackFn)
```